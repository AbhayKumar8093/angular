export class Article {
    id: number;
    title: string;
    category: string;
} 
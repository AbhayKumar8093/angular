import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-contents',
  templateUrl: './body-contents.component.html',
  styleUrls: ['./body-contents.component.scss']
})
export class BodyContentsComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}

export class SkillModel {
	id: number;
  name: string;
}
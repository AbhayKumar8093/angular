export class PeoplesModel {
	id: number;
  name: string;
  photo: string;
  designation: string;
}

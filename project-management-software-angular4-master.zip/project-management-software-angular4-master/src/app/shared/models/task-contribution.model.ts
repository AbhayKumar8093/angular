export class TaskContributionModel {
	id: number;
  people: number;
  data: Array<any>;
}

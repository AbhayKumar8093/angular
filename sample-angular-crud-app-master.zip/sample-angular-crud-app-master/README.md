# SampleCrud

This project is updated to [Angular CLI](https://github.com/angular/angular-cli) version 8. This app is simple angular CRUD app which is meant for getting started project. This project can be extended to accomodate any enterprise based features.

## Follow below steps

First you need to install yeoman generator globally. Later on, you can type below command

### yo sample-crud-angular:application

![1st](https://user-images.githubusercontent.com/3886381/49565405-0e267700-f94d-11e8-9afd-6671a733e987.png)

![2nd](https://user-images.githubusercontent.com/3886381/49565406-0ebf0d80-f94d-11e8-9844-ea7012b72256.png)

![3rd](https://user-images.githubusercontent.com/3886381/49565407-0ebf0d80-f94d-11e8-97ad-b29de3eff9b1.png)

![4th](https://user-images.githubusercontent.com/3886381/49565408-0f57a400-f94d-11e8-9a3e-b444ebfce8f7.png)

![5th](https://user-images.githubusercontent.com/3886381/49565409-0ff03a80-f94d-11e8-95d6-f80cd4d7f26b.png)

![6th](https://user-images.githubusercontent.com/3886381/49565410-0ff03a80-f94d-11e8-9e59-7b761578702c.png)

![7th](https://user-images.githubusercontent.com/3886381/49565412-1088d100-f94d-11e8-9834-4189d53bbed6.png)

![8th](https://user-images.githubusercontent.com/3886381/49565413-1088d100-f94d-11e8-9344-7f24fea1e47a.png)

![9th](https://user-images.githubusercontent.com/3886381/49565415-1088d100-f94d-11e8-8fdf-064bab291618.png)

![10th](https://user-images.githubusercontent.com/3886381/49565416-11216780-f94d-11e8-89e6-72cd955893e4.png)

![11th](https://user-images.githubusercontent.com/3886381/58373651-04222000-7f4f-11e9-8eaf-d9c713a67635.png)

![12th](https://user-images.githubusercontent.com/3886381/49565421-12529480-f94d-11e8-9a30-3fd08ddcb1d7.png)

![13th](https://user-images.githubusercontent.com/3886381/49565422-12529480-f94d-11e8-8c85-c0d01c9c12c2.png)













# Basic CRUD

Basic CRUD with Angular 8.1 

### Start DB server
```
cd /src/app/data
json-server --watch db.json
``` 

### Start App
```
npm install
ng serve
``` 

